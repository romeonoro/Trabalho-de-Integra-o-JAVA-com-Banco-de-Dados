/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package conexao;

import DAO.LogAcaoDAO;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Administrator
 */
public class InterfaceRelatorioAtrasados extends javax.swing.JFrame {

    /**
     * Creates new form InterfaceRelatorioAtrasados
     */
    public InterfaceRelatorioAtrasados() {
        initComponents();
        preencheTabelaAtrasados();
        setSize(900, 700);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblLogAcao = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Relatório de Itens Atrasados");
        getContentPane().setLayout(null);

        tblLogAcao.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item", "Usuário", "Sala", "Atrasado deste"
            }
        ));
        jScrollPane1.setViewportView(tblLogAcao);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(0, 90, 860, 565);

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 3, 18)); // NOI18N
        jLabel1.setText("Relatório de Atrasados");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(310, 0, 273, 78);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void preencheTabelaAtrasados() {
        LogAcaoDAO lDAO = new LogAcaoDAO();
        List<Object[]> listaAtrasados = lDAO.getItensAtrasados();
        DefaultTableModel tabelaAtrasados = (DefaultTableModel) tblLogAcao.getModel();

        tabelaAtrasados.setNumRows(0); 

        for (Object[] dados : listaAtrasados) {
            tabelaAtrasados.addRow(dados); 
        }
    }

    
    public static void main(String args[]) {
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InterfaceRelatorioAtrasados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InterfaceRelatorioAtrasados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InterfaceRelatorioAtrasados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InterfaceRelatorioAtrasados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InterfaceRelatorioAtrasados().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblLogAcao;
    // End of variables declaration//GEN-END:variables
}
